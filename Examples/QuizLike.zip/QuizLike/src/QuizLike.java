
import java.util.Scanner;

public class QuizLike {
    static String getNameForNumber(int number) {
        if (0 == number) {
            return "Zero";
        } else if (1 == number) {
            return "One";
        } else if (1 == number) {
            return "One";
        } else if (2 == number) {
            return "Two";
        } else if (3 == number) {
            return "Three";
        } else if (4 == number) {
            return "Four";
        } else if (5 == number) {
            return "Five";
        } else if (6 == number) {
            return "Six";
        } else if (7 == number) {
            return "Seven";
        } else if (8 == number) {
            return "Eight";
        } else if (9 == number) {
            return "Nine";
        } else {
            return "Too Big";
        }
    }

    public static void main(String[] args) throws Exception {
        System.out.print("Enter a single digit number: ");
        java.util.Scanner inputScanner = new java.util.Scanner(System.in);
        System.out.println(getNameForNumber(inputScanner.nextByte()));
    }
}
