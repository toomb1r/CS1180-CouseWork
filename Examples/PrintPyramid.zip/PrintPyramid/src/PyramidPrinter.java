import java.util.Scanner;

public class PyramidPrinter {

    static void printPyramidRow(int numberOfDots) {
        while (0 < numberOfDots) {
            System.out.print(".");
            numberOfDots -= 1;
        }
    }

    // This is just like printPyramidRow() except that it prints
    // spaces instead of dots.
    static void printNumberOfSpaces(int number) {
        while (0 < number) {
            System.out.print(" ");
            number -= 1;
        }
    }

    /// Print a pyramid with base containing at least baseSize dots.
    /// The top row (if any) of a pyramid starts with 1 dot, and
    // each subsequent row adds tow dot to the preceding row.
    static void printPyramid(int baseSize) {
        int numberOfDotsPerRow = 1;
        int numberOfSpacesNeeded = baseSize / 2;
        while (numberOfDotsPerRow <= baseSize) {
            printNumberOfSpaces(numberOfSpacesNeeded);
            printPyramidRow(numberOfDotsPerRow);
            System.out.print("\n");
            numberOfDotsPerRow += 2;
            numberOfSpacesNeeded -= 1;
        }
    }

    public static void main(String[] args) throws Exception {
        java.util.Scanner baseSizeScanner = new java.util.Scanner(System.in);
        System.out.print("Enter Size of Base: ");
        int baseSize = baseSizeScanner.nextInt();
        printPyramid(baseSize);
    }
}
