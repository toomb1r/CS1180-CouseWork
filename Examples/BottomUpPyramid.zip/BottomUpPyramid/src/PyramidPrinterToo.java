import java.util.Scanner;

public class PyramidPrinterToo {
    // Print the number of dots specified.
    static void printChars(int numberOfDots, char c) {
        while (0 < numberOfDots) {
            System.out.print(c);
            numberOfDots--;
        }
    }

    // Return the number of dots needed for the specified row. Row 0
    // (if present) contains 1 dot. Each row after that contains two more
    // dot than the preceding row
    static int calcNumberOfDotsOnRow(int rowNumber) {
        int result = 0;
        if (0 > rowNumber) {
            // Error
        } else {
            if (0 == rowNumber) {
                result = 1;
            } else {
                result = rowNumber * 2 + 1;
            }
        }
        return result;
    }

    static int calcNumberOfRowsNeeded(int numberOfDotsInBaseRow) {
        return numberOfDotsInBaseRow / 2;
    }

    /// Print a pyramid with base containing at least baseSize dots.
    /// The top row (if any) of a pyramid starts with 1 dot, and
    /// each subsequent row adds tow dot to the preceding row.
    public static void main(String[] args) throws Exception {
        // printDots(0);
        // System.out.print("\n");
        // printDots(1);
        // System.out.print("\n");
        // printDots(2);
        // System.out.print("\n");
        // printDots(calcNumberOfDotsOnRow(0));
        // System.out.print("\n");
        // printDots(calcNumberOfDotsOnRow(1));
        // System.out.print("\n");
        // printDots(calcNumberOfDotsOnRow(2));
        // System.out.print("\n");
        java.util.Scanner baseSizeScanner = new java.util.Scanner(System.in);
        System.out.print("Enter Size of Base: ");
        int baseSize = baseSizeScanner.nextInt();
        int numRows = calcNumberOfRowsNeeded(baseSize);
        int lastRow = calcNumberOfDotsOnRow(numRows) + 1;
        while (0 <= numRows) {
            int numDots = lastRow - calcNumberOfDotsOnRow(numRows);
            printChars((lastRow - numDots) / 2, ' ');
            printChars(numDots, '.');
            System.out.print("\n");
            numRows--;
        }
    }
}
