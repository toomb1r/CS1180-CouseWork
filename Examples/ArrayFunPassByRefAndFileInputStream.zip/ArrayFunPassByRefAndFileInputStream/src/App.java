import java.io.*;  
import java.util.Scanner; 

 
public class App {
    static long readLineByLineExample2() throws Exception 
    {  
        long result = 0;
        //the file to be opened for reading  
        FileInputStream fis= new FileInputStream("C:/Users/student/Desktop/ArrayFun/bin/Demo.txt");       
        Scanner sc=new Scanner(fis);    //file to be scanned  
        //returns true if there is another line to read  
        while(sc.hasNextLine())  {  
            //System.out.println(sc.nextLine());  
            result += 1;    //returns the line that was skipped  
            sc.nextLine();
        }  
        sc.close();     //closes the scanner  
        return result;
    }  

    static void calcPowerOfTwo(long[] power) throws Exception {
        long result = 0;
        if(0 <= power[0]) {
            result = 1;
        }
        if (power[0] > 62) {
            power[0] = 62;
        }
        for(int i = 0; i < power[0]; i++) {
            result *= 2;
        }
        power[0] = result;
    }

    public static void main(String[] args) throws Exception {
        System.out.println("lines = " + readLineByLineExample2());
        long[] myArray = {62};
        calcPowerOfTwo(myArray);
        System.out.println("a = " + myArray[0]);
    }
}
