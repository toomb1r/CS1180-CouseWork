
import java.util.Scanner;

public class EnglishNumberNames {
    static String[] namesInOnesColumn;
    static String[] namesInTensColumn;

    /// This method returns the English name of any number in the range
    /// 0 to 99. If number is 0, and empty string is returned. If number is
    /// less than 0 or greater than 99, the string, "Error", is returned.
    static String getNameForNumber0to99(int number) {
        String result = "Error ";

        if (0 < number && 20 > number) {
            result = EnglishNumberNames.namesInOnesColumn[number % 20];
        } else if (20 <= number && 100 > number) {
            result = EnglishNumberNames.namesInTensColumn[number / 10];
            result += EnglishNumberNames.namesInOnesColumn[number % 10];
        }
        return result;
    }

    /// This method returns the English name of any number in the range
    /// -99999 to 99999.
    static String getNameForNumberMinus99999to99999(int number) {
        String result = "";

        return result;
    }

    /// This method returns the English name of any number in the range
    /// -999999 to 999999.
    static String getNameForNumberMinus999999to999999(int number) {
        String result = "";
        if (-1000000 >= number || 1000000 <= number) {
            result = "Error";
        } else if (0 == number) {
            // The only time return "zero" is when the number is exactly zero
            result = "Zero";
        } else {
            int inputHundredThousands = (number / 100000) % 10;
            if (0 < inputHundredThousands) {
                result += EnglishNumberNames.namesInOnesColumn[inputHundredThousands % 10];
                result += "Hundred ";
            }
            int inputThousands = (number / 1000) % 100;
            if (0 < inputThousands) {
                result += getNameForNumber0to99(inputThousands) + "Thousand ";
            }
            int inputHundreds = (number / 100) % 10;
            if (0 < inputHundreds) {
                result += EnglishNumberNames.namesInOnesColumn[number % 10] + "Hundred ";
            }
            int inputTens = number % 100;
            if (0 < inputTens) {
                result += getNameForNumber0to99(inputTens);
            }
        }
        return result;
    }

    public static void main(String[] args) throws Exception {
        EnglishNumberNames.namesInOnesColumn = new String[20];
        EnglishNumberNames.namesInOnesColumn[0] = "";
        EnglishNumberNames.namesInOnesColumn[1] = "One ";
        EnglishNumberNames.namesInOnesColumn[2] = "Two ";
        EnglishNumberNames.namesInOnesColumn[3] = "Three ";
        EnglishNumberNames.namesInOnesColumn[4] = "Four ";
        EnglishNumberNames.namesInOnesColumn[5] = "Five ";
        EnglishNumberNames.namesInOnesColumn[6] = "Six ";
        EnglishNumberNames.namesInOnesColumn[7] = "Seven ";
        EnglishNumberNames.namesInOnesColumn[8] = "Eight ";
        EnglishNumberNames.namesInOnesColumn[9] = "Nine ";
        EnglishNumberNames.namesInOnesColumn[10] = "Ten ";
        EnglishNumberNames.namesInOnesColumn[11] = "Eleven ";
        EnglishNumberNames.namesInOnesColumn[12] = "Twelve ";
        EnglishNumberNames.namesInOnesColumn[13] = "Thirteen ";
        EnglishNumberNames.namesInOnesColumn[14] = "Fourteen ";
        EnglishNumberNames.namesInOnesColumn[15] = "Fifteen ";
        EnglishNumberNames.namesInOnesColumn[16] = "Sixteen ";
        EnglishNumberNames.namesInOnesColumn[17] = "Seventeen ";
        EnglishNumberNames.namesInOnesColumn[18] = "Eighteen ";
        EnglishNumberNames.namesInOnesColumn[19] = "Nineteen ";
        EnglishNumberNames.namesInTensColumn = new String[10];
        EnglishNumberNames.namesInTensColumn[0] = "";
        EnglishNumberNames.namesInTensColumn[1] = "";
        EnglishNumberNames.namesInTensColumn[2] = "Twenty ";
        EnglishNumberNames.namesInTensColumn[3] = "Thirty ";
        EnglishNumberNames.namesInTensColumn[4] = "Fourty ";
        EnglishNumberNames.namesInTensColumn[5] = "Fifty ";
        EnglishNumberNames.namesInTensColumn[6] = "Sixty ";
        EnglishNumberNames.namesInTensColumn[7] = "Seventy ";
        EnglishNumberNames.namesInTensColumn[8] = "Eighty ";
        EnglishNumberNames.namesInTensColumn[9] = "Ninety ";
        System.out.print("Enter a number -999,999 to 999,999: ");
        java.util.Scanner inputScanner = new java.util.Scanner(System.in);
        int inputNumber = inputScanner.nextInt();
        if (-999999 > inputNumber || 999999 < inputNumber) {
            System.out.print("Input error: out of range -999,999 to 999,999");
        } else {
            if (0 > inputNumber) {
                System.out.print("Minus ");
                inputNumber *= -1;
            }
            System.out.print(getNameForNumberMinus999999to999999(inputNumber));
        }
        System.out.print("\n");
    }
}
