package com.company;

import java.util.Scanner;

public class Main {

    static String[] namesInOnesColumn = {"", "One ", "Two ", "Three ", "Four ", "Five", "Six ", "Seven ", "Eight", "Nine ", "Ten ", "Eleven ", "Twelve ", "Thirteen ", "Fourteen ", "Fifteen ", "Sixteen ", "Seventeen ", "Eighteen ", "Nineteen "};
    static String[] namesInTensColumn = {"", "", "Twenty ", "Thirty ", "Forty ", "Fifty ", "Sixty ", "Seventy ", "Eighty ", "Ninety "};

    public static void main(String[] args) throws Exception {

        System.out.print("Enter a number -999,999 to 999,999: ");
        Scanner inputScanner = new Scanner(System.in);
        int inputNumber = inputScanner.nextInt();
        if (-999999 > inputNumber || 999999 < inputNumber) {
            System.out.print("Input error: out of range -999,999 to 999,999");
        } else {
            if (0 > inputNumber) {
                System.out.print("Minus ");
                inputNumber *= -1;
            }
            System.out.print(getNameForNumberMinus999999to999999(inputNumber));
        }
        System.out.print("\n");
        inputScanner.close();
    }

    /// This method returns the English name of any number in the range
    /// 0 to 99. If number is 0, and empty string is returned. If number is
    /// less than 0 or greater than 99, the string, "Error", is returned.
    static String getNameForNumber0to99(int number) {
        String result = "Error ";

        if (0 < number && 20 > number) {
            result = namesInOnesColumn[number % 20];
        } else if (20 <= number && 100 > number) {
            result = namesInTensColumn[number / 10];
            result += namesInOnesColumn[number % 10];
        }
        return result;
    }

    /// This method returns the English name of any number in the range
    /// -999999 to 999999.
    static String getNameForNumberMinus999999to999999(int number) {

        String result = "";
        if (-1000000 >= number || 1000000 <= number) {
            result = "Error";
        } else if (0 == number) {
            // The only time return "zero" is when the number is exactly zero
            result = "Zero";
        } else {
            int inputHundredThousands = (number / 100000) % 10;
            if (0 < inputHundredThousands) {
                result += namesInOnesColumn[inputHundredThousands % 10];
                result += "Hundred ";
            }
            int inputThousands = (number / 1000) % 100;
            if (0 < inputThousands) {
                result += getNameForNumber0to99(inputThousands) + "Thousand ";
            }
            int inputHundreds = (number / 100) % 10;
            if (0 < inputHundreds) {
                result += namesInOnesColumn[inputHundreds % 10] + "Hundred ";
            }
            int inputTens = number % 100;
            if (0 < inputTens) {
                result += getNameForNumber0to99(inputTens);
            }
        }
        return result;
    }
}