
// This class ENCAPSULATES information about 2D points. Each point has 
// an x and a y coordinate
public class WSUPoint {
    double x; // The x coordinate
    double y; // The y coordinate

    // Constructor: a method with the same name as the class is used
    // to initialize new instances of teh class
    WSUPoint(double x, double y) {
        this.x = x;
        this.y = y;
    }

    // Print interesting information about the point
    void print() {
        System.out.print("{" + x + ", " + y + "}");
    }

    // Print interesting information about the point
    void println() {
        print();
        System.out.print("\n");
    }

    double distanceToPoint(WSUPoint otherPoint) {
        double deltaX = otherPoint.x - x;
        double deltaY = otherPoint.y - y;

        // Distance formula
        return Math.sqrt(deltaX * deltaX + deltaY * deltaY);
    }
}