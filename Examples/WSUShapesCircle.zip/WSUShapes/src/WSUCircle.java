
// This class ENCAPSULATES information about 2D circles. Each cicle has 
// a center and a radius
public class WSUCircle {
    WSUPoint m_center; // Center of the circle
    double m_radius; // radius of the circle

    // Constructor assures that all instnaces are initialized
    WSUCircle(WSUPoint center, double radius) {
        m_center = center;
        m_radius = radius;
    }

    // output interesting information about the circle isntance
    void print() {
        System.out.print("{center: ");
        m_center.print();
        System.out.print(" radius: " + m_radius + "}");
    }

    // output interesting information about the circle isntance
    void println() {
        print();
        System.out.print("\n");
    }

    // Return teh area of teh circle instance
    double getArea() {
        return Math.PI * m_radius * m_radius;
    }

    // Returns true if and only (iff) point p is within the circle
    Boolean isPointWithin(WSUPoint p) {
        return m_center.distanceToPoint(p) <= m_radius;
    }
}
