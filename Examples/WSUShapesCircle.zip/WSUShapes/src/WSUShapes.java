import java.util.ArrayList;
import java.util.Random;

public class WSUShapes {
    // Return tru if and only if the absolute vlaue of the difference
    // between valueA and ValueB is less than teh absolute value of delta
    public static Boolean isWithinDelta(double valueA, double valueB, double delta) {
        return Math.abs(delta) > Math.abs(valueA - valueB);
    }

    public static void main(String[] args) throws Exception {
        ArrayList<WSUPoint> points = new ArrayList<WSUPoint>();

        for (int i = 0; i < 100; i++) {
            double randomX = new Random().nextDouble() * 100.0 - 50.0;
            double randomY = new Random().nextDouble() * 100.0 - 50.0;
            points.add(new WSUPoint(randomX, randomY));
        }

        WSUPoint origin = new WSUPoint(0.0, 0.0);
        WSUPoint testA = new WSUPoint(0.0, 0.0);
        WSUPoint testB = new WSUPoint(5.0, 0.0);
        WSUPoint testC = new WSUPoint(0.0, 5.0);
        WSUPoint testD = new WSUPoint(3.0, 4.0);

        // Test distance calculation
        assert isWithinDelta(origin.distanceToPoint(testA), 0.0, 0.0000001);
        assert isWithinDelta(origin.distanceToPoint(testB), 5.0, 0.0000001);
        assert isWithinDelta(origin.distanceToPoint(testC), 5.0, 0.0000001);
        assert isWithinDelta(origin.distanceToPoint(testD), 5.0, 0.0000001);

        ArrayList<WSUPoint> selectedPoints = new ArrayList<WSUPoint>();

        double candidateDistance = 0.0;
        WSUPoint candidatePoint = origin;
        for (WSUPoint p : points) {
            double pDistance = origin.distanceToPoint(p);
            if (pDistance > candidateDistance) {
                candidateDistance = pDistance;
                candidatePoint = p;
                selectedPoints = new ArrayList<WSUPoint>();
                selectedPoints.add(p);
            } else if (pDistance == candidateDistance) {
                selectedPoints.add(p);
            }
        }

        System.out.print("The farthest point is ");
        selectedPoints.get(0).print();
        System.out.print(" at " + candidateDistance + "from origin.\n");
        System.out.println("Exactly " + selectedPoints.size() + " points are at that distance.");
    }
}
