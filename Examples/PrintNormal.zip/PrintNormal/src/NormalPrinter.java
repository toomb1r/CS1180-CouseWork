import java.util.Scanner;
import java.util.regex.Pattern;

public class NormalPrinter {

    /// It is generally useful to be able to calculate the
    /// length of a vector. In this particular example, the
    /// length of the vector is being used to normalize a
    /// vector by dividing each component of the vector by
    /// the length of the vector.
    static double getLength(double x, double y, double z) {
        return Math.sqrt(x * x + y * y + z * z);
    }

    /// Print a nicely formatted string describing the vector defined by
    /// x, y, and z.
    /// Output one normalized vector per line. Output three digits in
    /// the fractional part of each vector component.
    static void printNormalized(double x, double y, double z) {
        double length = getLength(x, y, z);
        String xString = String.format("%.3f", x / length);
        String yString = String.format("%.3f", y / length);
        String zString = String.format("%.3f", z / length);
        System.out.println("{" + xString + ", " + yString + ", " + zString + "}");
    }

    public static void main(String[] args) throws Exception {
        java.util.Scanner vectorScanner = new java.util.Scanner(System.in);
        vectorScanner.useDelimiter("\\s*[{},]\\s*");
        while (vectorScanner.hasNext()) {
            /// Read from System.in a three component vectors encoded
            /// as strings of the form {x, y, z} where x, y, and z are
            /// double precision floating point.
            if (!vectorScanner.hasNextDouble()) {
                // Skip over characters that aren't part of a double
                vectorScanner.next();
            }
            double x = vectorScanner.nextDouble();
            if (!vectorScanner.hasNextDouble()) {
                // Skip over characters that aren't part of a double
                vectorScanner.next();
            }
            double y = vectorScanner.nextDouble();
            if (!vectorScanner.hasNextDouble()) {
                // Skip over characters that aren't part of a double
                vectorScanner.next();
            }
            double z = vectorScanner.nextDouble();
            printNormalized(x, y, z);
        }
    }
}
