public class App {

    private static int calulateSquare(int x) {
        return x * x;
    }

    private static void printVericalPart(int numColumns) {
        for (int x = 0; x < numColumns; x += 1) {
            System.out.print("    |   |   ");
        }
        System.out.print("\n");
    }

    private static void printHorizontalPart(int columnsNumber) {
        for (int x = 0; x < columnsNumber; x += 1) {
            System.out.print(" ___________");
        }
        System.out.print("\n");
    }

    private static void printRowOfBoards(int columnsNumber) {
        printVericalPart(columnsNumber);
        printHorizontalPart(columnsNumber);
        printVericalPart(columnsNumber);
        printHorizontalPart(columnsNumber);
        printVericalPart(columnsNumber);
        System.out.print("\n");
    }

    private static void printTicTacToeGrid(int rowsNumber, int columnsNumber) {
        for (int y = 0; y < rowsNumber; y += 1) {
            printRowOfBoards(columnsNumber);
        }
    }

    public static void main(String[] args) throws Exception {
        printTicTacToeGrid(3, 1);
        printTicTacToeGrid(5, 3);
    }
}
